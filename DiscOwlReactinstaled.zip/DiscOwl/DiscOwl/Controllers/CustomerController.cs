﻿using DiscOwl.BusinessAccessLayer;
using DiscOwl.DataAccessLayer;
using DiscOwl.Models;
using DiscOwl.Security;
using DiscOwl.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace DiscOwl.Controllers
{
    public class CustomerController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            return RedirectToAction("Register");
        }

        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(CustomerViewModel customerVM)
        {
            if (ModelState.IsValid)
            {
                CustomerBusiness bs = new CustomerBusiness();

                customerVM = bs.ValidateCustomer(customerVM);

                if (customerVM != null)
                {
                    Customer customer = bs.GetEntity(customerVM);

                    using (DALDisc dal = new DALDisc())
                    {
                        dal.CustomerDbSet.Add(customer);

                        if (dal.SaveChanges() != 0)
                        {
                            return RedirectToAction("Index", "Home");
                        }
                    }
                }
            }

            return View();
        }

        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginViewModel login)
        {
            if(ModelState.IsValid)
            {
                Customer authUser = null;

                using (DALDisc dal = new DALDisc())
                {
                    string hashedPass = ShaUtils.GenerateSHA256String(login.Password);

                    authUser = dal.CustomerDbSet
                                            .FirstOrDefault(i => i.Name.ToLower() == login.Username.ToLower() && i.Password == hashedPass);
                }

                if (authUser != null)
                {
                    FormsAuthentication.SetAuthCookie(authUser.Name, false);
                    Session["USUARIO"] = authUser;

                    return RedirectToAction("Index", "Home");
                }
            }

            ModelState.AddModelError("CredentialError", "Usuario y contraseña incorrectos.");
            return View();
        }

        [HttpGet]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session["USUARIO"] = null;
            Session.Abandon();
            Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", ""));

            return RedirectToAction("Index", "Home");
        }
    }
}