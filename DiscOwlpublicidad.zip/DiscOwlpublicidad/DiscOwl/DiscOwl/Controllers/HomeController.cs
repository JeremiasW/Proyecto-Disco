﻿using DiscOwl.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DiscOwl.Controllers
{
    /// <summary>
    /// Home MVC controller.
    /// </summary>
    public class HomeController : Controller
    {
        /// <summary>
        /// [HttpGet] Index method.
        /// </summary>
        /// <returns>Returns Index view.</returns>
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }
    }
}