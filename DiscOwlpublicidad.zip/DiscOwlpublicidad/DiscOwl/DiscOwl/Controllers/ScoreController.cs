﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DiscOwl.Controllers
{
    /// <summary>
    /// Score MVC controller.
    /// </summary>
    public class ScoreController : Controller
    {
        /// <summary>
        /// [HttpGet] Index method.
        /// </summary>
        /// <returns>Redirect to GetScore method.</returns>
        [HttpGet]
        public ActionResult Index()
        {
            return RedirectToAction("GetScore");
        }

        /// <summary>
        /// [HttpGet] GetScore method.
        /// </summary>
        /// <returns>GetScore view.</returns>
        [HttpGet]
        public ActionResult GetScore()
        {
            return View();
        }
    }
}