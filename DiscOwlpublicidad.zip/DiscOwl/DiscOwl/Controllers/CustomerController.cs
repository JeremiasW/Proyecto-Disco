﻿using DiscOwl.BusinessAccessLayer;
using DiscOwl.DataAccessLayer;
using DiscOwl.Models;
using DiscOwl.Security;
using DiscOwl.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace DiscOwl.Controllers
{
    /// <summary>
    /// Customer MVC controller.
    /// </summary>
    public class CustomerController : Controller
    {
        /// <summary>
        /// [HttpGet] Index method.
        /// </summary>
        /// <returns>Redirecto to Register method.</returns>
        [HttpGet]
        public ActionResult Index()
        {
            return RedirectToAction("Register");
        }

        /// <summary>
        /// [HttpGet] Register method.
        /// </summary>
        /// <returns>Register view.</returns>
        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        /// <summary>
        /// [HttpPost] Register method.
        /// </summary>
        /// <param name="customerVM">Customer from view.</param>
        /// <returns>If customer is ok, returns Index from Home controller, else 
        /// returns Register view.</returns>
        [HttpPost]
        public ActionResult Register(CustomerViewModel customerVM)
        {
            if (ModelState.IsValid)
            {
                CustomerBusiness bs = new CustomerBusiness();

                customerVM = bs.ValidateCustomer(customerVM);

                if (customerVM != null)
                {
                    Customer customer = bs.GetEntity(customerVM);

                    using (DALDisc dal = new DALDisc())
                    {
                        dal.CustomerDbSet.Add(customer);

                        if (dal.SaveChanges() != 0)
                        {
                            return RedirectToAction("Index", "Home");
                        }
                    }
                }
            }

            return View();
        }

        /// <summary>
        /// [HttpGet] Login method.
        /// </summary>
        /// <returns>Login view.</returns>
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        /// <summary>
        /// [HttpPost] Login method.
        /// </summary>
        /// <param name="login">Login data from view.</param>
        /// <returns>If login is ok, returns Index from Home controller, else
        /// returns Login view.</returns>
        [HttpPost]
        public ActionResult Login(LoginViewModel login)
        {
            if(ModelState.IsValid)
            {
                Customer authUser = null;

                using (DALDisc dal = new DALDisc())
                {
                    string hashedPass = ShaUtils.GenerateSHA256String(login.Password);

                    authUser = dal.CustomerDbSet
                                            .FirstOrDefault(i => i.Name.ToLower() == login.Username.ToLower() && i.Password == hashedPass);
                }

                if (authUser != null)
                {
                    FormsAuthentication.SetAuthCookie(authUser.Name, false);
                    Session["USUARIO"] = authUser;

                    return RedirectToAction("Index", "Home");
                }
            }

            ModelState.AddModelError("CredentialError", "Usuario y contraseña incorrectos.");
            return View();
        }

        /// <summary>
        /// [HttpGet] Logout method.
        /// </summary>
        /// <returns>Index method from Home controller.</returns>
        [HttpGet]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session["USUARIO"] = null;
            Session.Abandon();
            Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", ""));

            return RedirectToAction("Index", "Home");
        }
    }
}