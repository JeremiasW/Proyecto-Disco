﻿


$(document).ready(function ()
{
    var ready = null;

    ready = new elements();

    $("#name").on("click", function ()
    {
        $(this).val("");
    });

    $("#typeName").on("click", function ()
    {
        $(this).val("");
    });

    $("#searchByName").on("click", function ()
    {
        $.ajax({
            "url": "/api/MusicApi/SearchByName",
            "type": "GET",
            "contentType": 'application/json',
            "data": { "name": $("#name").val() },
            "dataType": "json",
            "success": function(data)
            {
                //console.log(JSON.stringify(data));
                contenido1 = data;
                elements.prototype.tablatodo();
            }
        });
    });

    $("#searchByVotes").on("click", function ()
    {
        $.ajax({
            "url": "/api/MusicApi/SearchByVotes",
            "type": "GET",
            "contentType": 'application/json',
            "dataType": "json",
            "success": function(data)
            {
                //console.log(JSON.stringify(data));
                contenido1 = data;
                elements.prototype.tablatodo();
            }
        });
    });

    $("#searchByType").on("click", function ()
    {
        $.ajax({
            "url": "/api/MusicApi/SearchByType",
            "type": "GET",
            "contentType": 'application/json',
            "data": { "typeName": $("#typeName").val() },
            "dataType": "json",
            "success": function(data)
            {
                //console.log(JSON.stringify(data));
                contenido1 = data;
                elements.prototype.tablatodo();
            }
        });
    });


    var object = null;

    $.ajax({
        "url": "/api/MusicApi/GetAll",
        "type": "GET",
        "contentType": 'application/json',
        "data": object,
        "dataType": "json",
        "success": function (data)
        {
            //console.log(JSON.stringify(data));
            contenido1 = data;
            elements.prototype.tablatodo();
        }
    });

    //$(".estrellitas").append(getEstrellas());
    //$(".star").on("click", getPuntuacion);

    //Función que t devuelve el div con clase stars con sus respectivos enlaces con svg .star
    
});

elements = function () {
    var contenido1;
};

elements.prototype.tablatodo = function()
{

    var tablero = $('<table id="tablero"></table>');
    $("#tabla").append(tablero);

    document.getElementById("tablero").innerHTML = "";

    var primerafila = $('<thead><tr><th>Título</th><th>Autor</th><th>Tipo</th><th>NºVotos</th><th>Valoración</th></tr></thead>');

    $("#tablero").append(primerafila);

    for(contador = 0; contador < contenido1.length; contador++)
    {
        var fila = $('<tr data-id=' + contenido1[contador].DiscId + '><td>' + contenido1[contador].DiscName +
           '</td><td>' + contenido1[contador].Author + '</td><td>' + contenido1[contador].TypeSet + '</td><td>' +
           contenido1[contador].Votes + '</td><td>' + this.getEstrellas(contenido1[contador].Votes, contenido1[contador].Score) + '</td></tr>');
        $("#tablero").append(fila);
    }

    $(".star").off();
    $(".star").on("click", getPuntuacion);
}
elements.prototype.getEstrellas = function (nVotos, puntuacion) {
    var media = 6 - (Math.round((puntuacion / nVotos) / 2));
    var cadena = "<div class='stars'>";
    for (var i = 1; i < 6; i++) {
        cadena = cadena + "<a class='star"+ ((media == i) ? " select" : "") + "' href='#'><svg><use xlink:href='#star'></use></svg></a>";
    }
    cadena = cadena + "</div>";
    return cadena
}

function getPuntuacion(event) {
    event.target.preventDefault;
    if ($("#logeado").length) {
        var value = $(event.target).parent().children().length - ($(event.target).index());//Posición de la estrella.
        var idDisco = $(event.target).closest("tr").data("id");//Id del disco al que se valora.
        //$(event.target).siblings(".selected").removeClass("selected");
        //$(event.target).addClass("selected");
        $.ajax({
            "url": "/api/MusicApi/UpdateScore",
            "type": "GET",
            "contentType": 'application/json',
            "data": { "score": (value * 2), "id": idDisco },
            "dataType": "json",
            "success": function (json) {
                //console.log(JSON.stringify(json));
            }
        });
    }
}
