﻿using DiscOwl.BusinessAccessLayer;
using DiscOwl.DataAccessLayer;
using DiscOwl.Models;
using DiscOwl.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace DiscOwl.Controllers
{
    public class ScoreApiController : ApiController
    {
        [HttpGet]
        [ActionName("GetTop")]
        public IHttpActionResult GetTop()
        {
            List<Disc> discSet = new List<Disc>();
            ICollection<DiscViewModel> vm = new List<DiscViewModel>();
            DiscBusiness bs = new DiscBusiness();

            using (DALDisc dal = new DALDisc())
            {
                discSet = dal.DiscDbSet
                                .Include("Performer")
                                .Include("DiscTypeSet")
                                .Include("ScoreSet")
                                .OrderByDescending(i => i.ScoreSet.Sum(p => p.ScoreValue))
                                .Take(5)
                                .ToList();

                vm = bs.GetViewModel(discSet);
            }

            return Ok(vm);
        }
    }
}