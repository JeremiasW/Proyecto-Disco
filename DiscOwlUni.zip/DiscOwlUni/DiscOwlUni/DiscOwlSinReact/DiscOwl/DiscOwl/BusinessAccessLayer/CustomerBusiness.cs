﻿using DiscOwl.DataAccessLayer;
using DiscOwl.Models;
using DiscOwl.Security;
using DiscOwl.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DiscOwl.BusinessAccessLayer
{
    public class CustomerBusiness
    {
        public CustomerViewModel ValidateCustomer(CustomerViewModel customerVM)
        {
            bool correctData = false;

            if(customerVM.Username.Length > 0 && customerVM.Password.Length > 0
                && customerVM.Email.Length > 0 && customerVM.BirthDate.Length > 0)
            {
                customerVM.RegisterDate = DateTime.Now;

                correctData = true;
            }

            if(correctData)
            {
                return customerVM;
            }
            else
            {
                return null;
            }
        }

        public Customer GetEntity(CustomerViewModel customerVM)
        {
            Customer customer = new Customer();

            customer.Name = customerVM.Username;
            customer.Password = ShaUtils.GenerateSHA256String(customerVM.Password);
            customer.Email = customerVM.Email;
            customer.BirthDate = DateTime.Parse(customerVM.BirthDate);
            customer.RegisterDate = customerVM.RegisterDate;

            return customer;
        }
    }
}