jQuery(document).ready(function(){
     $(".estrellitas").append(getEstrellas());
     $(".star").on("click", getPuntuacion);

     //Función que t devuelve el div con clase stars con sus respectivos enlaces con svg .star
     function getEstrellas()
     {
          var contenedor = $("<div class='stars'><div>");
          for(var i = 0; i < 5; i++)
          {
               contenedor.append("<a class='star' href='#'><svg><use xlink:href='#star'></use></svg></a>");
          }
          return contenedor;
     }
     function getPuntuacion()
     {
          //En la siguiente línea me las ingenio para devolver la posición de la estrella pulsada.
          //lo suyo sería cargar dicha posición como valor de puntuación de el disco en la Base de datos.
          console.log($(this).parent().children().length-($(this).index()));
          $(this).siblings(".selected").removeClass("selected");
          $(this).addClass("selected");
     }
});
