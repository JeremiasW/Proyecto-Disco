﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DiscOwl.ViewModel
{
    public class CustomerViewModel
    {
        [Required(ErrorMessage = "Nombre requerido")]
        public String Username { get; set; }

        [Required(ErrorMessage = "Contraseña requerida")]
        [DataType(DataType.Password)]
        public String Password { get; set; }

        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Las contraseñas no coinciden")]
        public String ConfirmPassword { get; set; }

        [Required(ErrorMessage = "Email requerido")]
        [DataType(DataType.EmailAddress)]
        public String Email { get; set; }

        [Required(ErrorMessage = "Fecha de nacimiento requerida")]
        [DataType(DataType.DateTime)]
        public String BirthDate { get; set; }

        public Nullable<System.DateTime> RegisterDate { get; set; }
    }
}