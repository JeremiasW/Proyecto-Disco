﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DiscOwl.Controllers
{
    public class ScoreController : Controller
    {
        public ActionResult Index()
        {
            return RedirectToAction("GetScore");
        }

        public ActionResult GetScore()
        {
            return View();
        }
    }
}