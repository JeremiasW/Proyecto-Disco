﻿using DiscOwl.DataAccessLayer;
using DiscOwl.Models;
using DiscOwl.Security;
using DiscOwl.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DiscOwl.BusinessAccessLayer
{
    /// <summary>
    /// Implements all business methods from Customer.
    /// </summary>
    public class CustomerBusiness
    {
        /// <summary>
        /// Validates all fields from customer view model.
        /// </summary>
        /// <param name="customerVM">Customer View Model sent from the View.</param>
        /// <returns>Returns null if validation was not correct, returns the object if it was.</returns>
        public CustomerViewModel ValidateCustomer(CustomerViewModel customerVM)
        {
            bool correctData = false;
            DateTime birthDate = new DateTime();

            if(customerVM.Username.Length > 0 && customerVM.Password.Length > 0
                && customerVM.Email.Length > 0 && customerVM.BirthDate.Length > 0)
            {
                if(customerVM.Password.Equals(customerVM.ConfirmPassword)
                    && DateTime.TryParse(customerVM.BirthDate, out birthDate))
                {
                    if(DateTime.Compare(birthDate, DateTime.Now) < 0)
                    {
                        customerVM.RegisterDate = DateTime.Now;

                        correctData = true;
                    }
                }
            }

            if(correctData)
            {
                return customerVM;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Gets Customer entity from Customer view model.
        /// </summary>
        /// <param name="customerVM">The Customer view model</param>
        /// <returns>Customer entity</returns>
        public Customer GetEntity(CustomerViewModel customerVM)
        {
            Customer customer = new Customer();

            customer.Name = customerVM.Username;
            customer.Password = ShaUtils.GenerateSHA256String(customerVM.Password);
            customer.Email = customerVM.Email;
            customer.BirthDate = DateTime.Parse(customerVM.BirthDate);
            customer.RegisterDate = customerVM.RegisterDate;

            return customer;
        }
    }
}