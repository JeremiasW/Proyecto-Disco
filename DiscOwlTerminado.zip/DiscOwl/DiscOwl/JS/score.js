﻿var contenido;
$(document).ready(function ()
{
    $.ajax({
        "url": "/api/ScoreApi/GetTop",
        "type": "GET",
        "contentType": 'application/json',
        "dataType": "json",
        "success": function (data) {
            contenido = data;
            google.charts.load('current', { 'packages': ['corechart'] });
            google.charts.setOnLoadCallback(drawChart);
        }
    });
});

function drawChart() {
    var datos = new google.visualization.DataTable();
    datos.addColumn('string', 'Topping');
    datos.addColumn('number', 'Slices');
    for (contador = 0; contador < contenido.length; contador++) {
        datos.addRows([
          [contenido[contador].DiscName, contenido[contador].Score],
        ]);
    }

    var options = {
        'title': 'Gráfica',
        'width': 600,
        'height': 500
    };

    var chart = new google.visualization.ColumnChart(document.getElementById('content'));
    chart.draw(datos, options);
}