﻿using DiscOwl.BusinessAccessLayer;
using DiscOwl.DataAccessLayer;
using DiscOwl.Models;
using DiscOwl.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace DiscOwl.Controllers
{
    /// <summary>
    /// Music Web Api controller.
    /// </summary>
    public class MusicApiController : ApiController
    {
        /// <summary>
        /// [HttpGet] GetAll method.
        /// </summary>
        /// <returns>All discs.</returns>
        [HttpGet]
        [ActionName("GetAll")]
        public IHttpActionResult GetAll()
        {
            List<Disc> discSet = new List<Disc>();
            ICollection<DiscViewModel> vm = new List<DiscViewModel>();
            DiscBusiness bs = new DiscBusiness();

            using (DALDisc dal = new DALDisc())
            {
                discSet = dal.DiscDbSet
                                .Include("Performer")
                                .Include("DiscTypeSet")
                                .Include("ScoreSet")
                                .ToList();

                vm = bs.GetViewModel(discSet);
            }

            return Ok(vm);
        }

        /// <summary>
        /// [HttpGet] SearchByName method.
        /// </summary>
        /// <param name="name">Name to be found.</param>
        /// <returns>All discs whose name is the same as argument.</returns>
        [HttpGet]
        [ActionName("SearchByName")]
        public IHttpActionResult SearchByName(String name)
        {
            DiscBusiness bs = new DiscBusiness();

            if (name != null)
            {
                List<Disc> discSet = new List<Disc>();
                ICollection<DiscViewModel> vm = new List<DiscViewModel>();

                name = name.TrimStart(' ');
                name = name.TrimEnd(' ');

                using (DALDisc dal = new DALDisc())
                {
                    discSet = dal.DiscDbSet
                            .Include("Performer")
                            .Include("DiscTypeSet")
                            .Include("ScoreSet")
                            .Where(d => d.Title.ToLower() == name.ToLower())
                            .ToList();

                    vm = bs.GetViewModel(discSet);
                }

                return Ok(vm);
            }

            return Ok(bs.GetAllGeneric());
        }

        /// <summary>
        /// [HttpGet] SearchByVotes method.
        /// </summary>
        /// <returns>All discs ordered descending by votes amount.</returns>
        [HttpGet]
        [ActionName("SearchByVotes")]
        public IHttpActionResult SearchByVotes()
        {
            List<Disc> discSet = new List<Disc>();
            ICollection<DiscViewModel> vm = new List<DiscViewModel>();
            DiscBusiness bs = new DiscBusiness();

            using (DALDisc dal = new DALDisc())
            {
                discSet = dal.DiscDbSet
                                .Include("Performer")
                                .Include("DiscTypeSet")
                                .Include("ScoreSet")
                                .OrderByDescending(i => i.ScoreSet.Count)
                                .ToList();

                vm = bs.GetViewModel(discSet);
            }

            return Ok(vm);
        }

        /// <summary>
        /// [HttpGet] SearchByType method.
        /// </summary>
        /// <param name="typeName">Type to be found.</param>
        /// <returns>All discs whose type list contains the same as argument.</returns>
        [HttpGet]
        [ActionName("SearchByType")]
        public IHttpActionResult SearchByType(String typeName)
        {
            DiscBusiness bs = new DiscBusiness();

            if (typeName != null)
            {
                List<Disc> discSet = new List<Disc>();
                ICollection<DiscViewModel> vm = new List<DiscViewModel>();

                typeName = typeName.TrimStart(' ');
                typeName = typeName.TrimEnd(' ');

                using (DALDisc dal = new DALDisc())
                {
                    discSet = dal.DiscDbSet
                        .Include("Performer")
                        .Include("DiscTypeSet")
                        .Include("ScoreSet")
                        .Where(i => i.DiscTypeSet.Any(p => p.TypeElement.TypeName.ToLower() == typeName.ToLower()))
                        .ToList();

                    vm = bs.GetViewModel(discSet);
                }

                return Ok(vm);
            }

            return Ok(bs.GetAllGeneric());
        }

        /// <summary>
        /// [HttpGet] UpdateScore method.
        /// </summary>
        /// <param name="score">New score.</param>
        /// <param name="id">Disc id.</param>
        /// <returns>The disc updated if all was correct, else returns HttpStatusCode No Content.</returns>
        [HttpGet]
        [ActionName("UpdateScore")]
        public IHttpActionResult UpdateScore(int score, int id)
        {
            if (User.Identity.IsAuthenticated)
            {
                string username = User.Identity.Name;

                using (DALDisc dal = new DALDisc())
                {
                    Score scoreUpdated = dal.ScoreDbSet
                                                    .Include("Customer")
                                                    .Where(i => i.DiscId == id && i.Customer.Name.ToLower() == username.ToLower())
                                                    .FirstOrDefault();

                    // If the customer has not voted yet in this disc, we create a new entry.
                    if (scoreUpdated == null)
                    {
                        scoreUpdated = new Score();

                        scoreUpdated.CustomerId = dal.CustomerDbSet
                                                            .Where(i => i.Name.ToLower() == username.ToLower())
                                                            .Select(i => i.Id)
                                                            .First();
                        scoreUpdated.DiscId = id;
                        scoreUpdated.ScoreValue = score;

                        dal.ScoreDbSet.Add(scoreUpdated);
                        dal.SaveChanges();
                    }
                    else
                    {
                        scoreUpdated.ScoreValue = score;

                        dal.Entry(scoreUpdated).State = System.Data.Entity.EntityState.Modified;
                        dal.SaveChanges();
                    }
                }

                List<Disc> discSet = new List<Disc>();
                ICollection<DiscViewModel> vm = new List<DiscViewModel>();
                DiscBusiness bs = new DiscBusiness();

                using (DALDisc dal = new DALDisc())
                {
                    discSet = dal.DiscDbSet
                                    .Include("Performer")
                                    .Include("DiscTypeSet")
                                    .Include("ScoreSet")
                                    .Where(i => i.DiscId == id)
                                    .ToList();

                    vm = bs.GetViewModel(discSet);
                }

                return Ok(vm);
            }

            return Content(HttpStatusCode.NoContent, "null");
        }
    }
}