﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DiscOwl.ViewModel
{
    public class BaseViewModel
    {
        public String ViewTitle { get; set; }
        public String Username { get; set; }
    }
}