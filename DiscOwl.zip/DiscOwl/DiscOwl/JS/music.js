﻿$(document).ready(function ()
{
    $("#name").on("click", function ()
    {
        $(this).val("");
    });

    $("#typeName").on("click", function ()
    {
        $(this).val("");
    });

    $("#searchByName").on("click", function ()
    {
        $.ajax({
            "url": "/api/MusicApi/SearchByName",
            "type": "GET",
            "contentType": 'application/json',
            "data": { "name": $("#name").val() },
            "dataType": "json",
            "success": function(json)
            {
                console.log(JSON.stringify(json));
            }
        });
    });

    $("#searchByVotes").on("click", function ()
    {
        $.ajax({
            "url": "/api/MusicApi/SearchByVotes",
            "type": "GET",
            "contentType": 'application/json',
            "dataType": "json",
            "success": function(json)
            {
                console.log(JSON.stringify(json));
            }
        });
    });

    $("#searchByType").on("click", function ()
    {
        $.ajax({
            "url": "/api/MusicApi/SearchByType",
            "type": "GET",
            "contentType": 'application/json',
            "data": { "typeName": $("#typeName").val() },
            "dataType": "json",
            "success": function(json)
            {
                console.log(JSON.stringify(json));
            }
        });
    });

    $("#score").on("click", function (event)
    {
        if ($(event.target).attr("type") == "button")
        {
            console.log($(event.target).val());
        }
    });

    var object = null;

    $.ajax({
        "url": "/api/MusicApi/GetAll",
        "type": "GET",
        "contentType": 'application/json',
        "data": object,
        "dataType": "json",
        "success": function (json)
        {
            console.log(JSON.stringify(json));
        }
    });
});