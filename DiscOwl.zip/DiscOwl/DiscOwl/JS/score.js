﻿$(document).ready(function ()
{
    $.ajax({
        "url": "/api/ScoreApi/GetTop",
        "type": "GET",
        "contentType": 'application/json',
        "dataType": "json",
        "success": function (json) {
            console.log(JSON.stringify(json));
        }
    });
});