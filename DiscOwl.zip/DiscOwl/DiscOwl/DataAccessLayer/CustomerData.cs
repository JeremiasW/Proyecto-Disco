﻿using DiscOwl.DTO;
using DiscOwl.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DiscOwl.DataAccessLayer
{
    public class CustomerData
    {
        public CustomerDTO Insert(CustomerDTO customerDTO)
        {
            Customer customer = this.ObjectToData(customerDTO);

            using (DALDisc dal = new DALDisc())
            {
                dal.CustomerDbSet.Add(customer);

                if(dal.SaveChanges() == 0)
                {
                    customerDTO = null;
                }
            }

            return customerDTO;
        }

        private Customer ObjectToData(CustomerDTO customerDTO)
        {
            Customer customer = new Customer();

            customer.Name = customerDTO.Name;
            customer.Password = customerDTO.Password;
            customer.BirthDate = customerDTO.BirthDate;
            customer.RegisterDate = customerDTO.RegisterDate;

            return customer;
        }
    }
}