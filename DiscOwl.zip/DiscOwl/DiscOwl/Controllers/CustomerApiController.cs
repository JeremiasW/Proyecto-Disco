﻿using DiscOwl.BusinessAccessLayer;
using DiscOwl.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace DiscOwl.Controllers
{
    public class CustomerApiController : ApiController
    {
        [HttpPost]
        [ActionName("Register")]
        public IHttpActionResult Register([FromBody] CustomerViewModel customerVM)
        {
            if(ModelState.IsValid)
            {
                CustomerBusiness bal = new CustomerBusiness();

                customerVM = bal.ValidateCustomer(customerVM);

                if (customerVM != null)
                {
                    if (bal.Insert(customerVM) != null)
                    {
                        return Ok();
                    }
                }
            }

            return Content(HttpStatusCode.BadRequest, "Error procesando la solicitud");
        }
    }
}