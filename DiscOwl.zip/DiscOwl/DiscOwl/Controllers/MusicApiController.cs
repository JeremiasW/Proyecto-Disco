﻿using DiscOwl.BusinessAccessLayer;
using DiscOwl.DataAccessLayer;
using DiscOwl.Models;
using DiscOwl.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace DiscOwl.Controllers
{
    public class MusicApiController : ApiController
    {
        [HttpGet]
        [ActionName("GetAll")]
        public IHttpActionResult GetAll()
        {
            List<Disc> discSet = new List<Disc>();
            ICollection<DiscViewModel> vm = new List<DiscViewModel>();
            DiscBusiness bs = new DiscBusiness();

            using (DALDisc dal = new DALDisc())
            {
                discSet = dal.DiscDbSet
                                .Include("Performer")
                                .Include("DiscTypeSet")
                                .Include("ScoreSet")
                                .ToList();

                vm = bs.GetViewModel(discSet);
            }

            return Ok(vm);
        }

        [HttpGet]
        [ActionName("SearchByName")]
        public IHttpActionResult SearchByName(String name)
        {
            List<Disc> discSet = new List<Disc>();
            ICollection<DiscViewModel> vm = new List<DiscViewModel>();
            DiscBusiness bs = new DiscBusiness();

            name = name.TrimStart(' ');
            name = name.TrimEnd(' ');

            using (DALDisc dal = new DALDisc())
            {
                discSet = dal.DiscDbSet
                        .Include("Performer")
                        .Include("DiscTypeSet")
                        .Include("ScoreSet")
                        .Where(d => d.Title.ToLower() == name.ToLower())
                        .ToList();

                vm = bs.GetViewModel(discSet);
            }

            return Ok(vm);
        }

        [HttpGet]
        [ActionName("SearchByVotes")]
        public IHttpActionResult SearchByVotes()
        {
            List<Disc> discSet = new List<Disc>();
            ICollection<DiscViewModel> vm = new List<DiscViewModel>();
            DiscBusiness bs = new DiscBusiness();

            using (DALDisc dal = new DALDisc())
            {
                discSet = dal.DiscDbSet
                                .Include("Performer")
                                .Include("DiscTypeSet")
                                .Include("ScoreSet")
                                .OrderByDescending(i => i.ScoreSet.Sum(p => p.ScoreValue))
                                .ToList();

                vm = bs.GetViewModel(discSet);
            }

            return Ok(vm);
        }

        [HttpGet]
        [ActionName("SearchByType")]
        public IHttpActionResult SearchByType(string typeName)
        {
            List<Disc> discSet = new List<Disc>();
            ICollection<DiscViewModel> vm = new List<DiscViewModel>();
            DiscBusiness bs = new DiscBusiness();

            typeName = typeName.TrimStart(' ');
            typeName = typeName.TrimEnd(' ');

            using (DALDisc dal = new DALDisc())
            {
                discSet = dal.DiscDbSet
                    .Include("Performer")
                    .Include("DiscTypeSet")
                    .Include("ScoreSet")
                    .Where(i => i.DiscTypeSet.Any(p => p.TypeElement.TypeName.ToLower() == typeName.ToLower()))
                    .ToList();

                vm = bs.GetViewModel(discSet);
            }

            return Ok(vm);
        }

        [HttpGet]
        [ActionName("UpdateScore")]
        public IHttpActionResult UpdateScore(int score, int id)
        {
            if (User.Identity.IsAuthenticated)
            {
                string username = User.Identity.Name;

                using (DALDisc dal = new DALDisc())
                {
                    Score scoreUpdated = dal.ScoreDbSet
                                                    .Include("Customer")
                                                    .Where(i => i.DiscId == id && i.Customer.Name.ToLower() == username.ToLower())
                                                    .FirstOrDefault();

                    // If the customer has not voted yet in this disc, we create a new entry.
                    if(scoreUpdated == null)
                    {
                        scoreUpdated = new Score();

                        scoreUpdated.CustomerId = dal.CustomerDbSet
                                                            .Where(i => i.Name.ToLower() == username.ToLower())
                                                            .Select(i => i.Id)
                                                            .First();
                        scoreUpdated.DiscId = id;
                        scoreUpdated.ScoreValue = score;

                        dal.ScoreDbSet.Add(scoreUpdated);
                        dal.SaveChanges();
                    }
                    else
                    {
                        scoreUpdated.ScoreValue = score;

                        dal.Entry(scoreUpdated).State = System.Data.Entity.EntityState.Modified;
                        dal.SaveChanges();
                    }
                }
            }

            List<Disc> discSet = new List<Disc>();
            ICollection<DiscViewModel> vm = new List<DiscViewModel>();
            DiscBusiness bs = new DiscBusiness();

            using (DALDisc dal = new DALDisc())
            {
                discSet = dal.DiscDbSet
                                .Include("Performer")
                                .Include("DiscTypeSet")
                                .Include("ScoreSet")
                                .ToList();

                vm = bs.GetViewModel(discSet);
            }

            return Ok(vm);
        }
    }
}