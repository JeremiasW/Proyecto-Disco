﻿using DiscOwl.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DiscOwl.Controllers
{
    /// <summary>
    /// Music MVC controller.
    /// </summary>
    public class MusicController : Controller
    {
        /// <summary>
        /// [HttpGet] Index method.
        /// </summary>
        /// <returns>Redirect to GetMusic method.</returns>
        [HttpGet]
        public ActionResult Index()
        {
            return RedirectToAction("GetMusic");
        }

        /// <summary>
        /// [HttpGet] GetMusic method.
        /// </summary>
        /// <returns>GetMusic view.</returns>
        [HttpGet]
        public ActionResult GetMusic()
        {
            return View();
        }
    }
}