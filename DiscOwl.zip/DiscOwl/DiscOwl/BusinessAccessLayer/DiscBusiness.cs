﻿using DiscOwl.DataAccessLayer;
using DiscOwl.Models;
using DiscOwl.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DiscOwl.BusinessAccessLayer
{
    public class DiscBusiness
    {
        public ICollection<DiscViewModel> GetViewModel(List<Disc> discSet)
        {
            List<DiscViewModel> vm = new List<DiscViewModel>();
            DiscViewModel dvm;

            foreach (Disc item in discSet)
            {
                dvm = new DiscViewModel();

                dvm.DiscId = item.DiscId;
                dvm.DiscName = item.Title;
                dvm.Author = item.Performer.PerformerName;
                dvm.Score = item.ScoreSet.Sum(i => i.ScoreValue);
                dvm.Votes = item.ScoreSet.Count;
                dvm.TypeSet = item.DiscTypeSet.Select(i => i.TypeElement.TypeName).ToList();

                vm.Add(dvm);
            }

            return vm;
        }
    }
}