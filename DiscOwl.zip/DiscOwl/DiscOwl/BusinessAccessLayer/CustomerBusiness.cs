﻿using DiscOwl.DataAccessLayer;
using DiscOwl.DTO;
using DiscOwl.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DiscOwl.BusinessAccessLayer
{
    public class CustomerBusiness
    {
        public CustomerViewModel ValidateCustomer(CustomerViewModel customerVM)
        {
            bool correctData = false;

            if(customerVM.Username.Length > 0 && customerVM.Password.Length > 0
                && customerVM.Email.Length > 0 && customerVM.BirthDate != null)
            {
                customerVM.RegisterDate = DateTime.Now;

                correctData = true;
            }

            if(correctData)
            {
                return customerVM;
            }
            else
            {
                return null;
            }
        }

        public CustomerViewModel Insert(CustomerViewModel customerVM)
        {
            CustomerDTO customerDTO = this.BusinessToObject(customerVM);
            CustomerData data = new CustomerData();

            customerDTO = data.Insert(customerDTO);

            if(customerDTO == null)
            {
                customerVM = null;
            }

            return customerVM;
        }

        private CustomerDTO BusinessToObject(CustomerViewModel customerVM)
        {
            CustomerDTO customerDTO = new CustomerDTO();

            customerDTO.Name = customerVM.Username;
            customerDTO.Password = customerVM.Password;
            customerDTO.BirthDate = DateTime.Parse(customerVM.BirthDate);
            customerDTO.RegisterDate = customerVM.RegisterDate;

            return customerDTO;
        }
    }
}