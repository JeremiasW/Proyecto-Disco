﻿


$(document).ready(function ()
{
    var ready = null;

    ready = new elements();

    $("#name").on("click", function ()
    {
        $(this).val("");
    });

    $("#typeName").on("click", function ()
    {
        $(this).val("");
    });

    $("#searchByName").on("click", function ()
    {
        $.ajax({
            "url": "/api/MusicApi/SearchByName",
            "type": "GET",
            "contentType": 'application/json',
            "data": { "name": $("#name").val() },
            "dataType": "json",
            "success": function(data)
            {
                console.log(JSON.stringify(data));
                contenido1 = data;
                elements.prototype.tablatodo();
            }
        });
    });

    $("#searchByVotes").on("click", function ()
    {
        $.ajax({
            "url": "/api/MusicApi/SearchByVotes",
            "type": "GET",
            "contentType": 'application/json',
            "dataType": "json",
            "success": function(data)
            {
                console.log(JSON.stringify(data));
                contenido1 = data;
                elements.prototype.tablatodo();
            }
        });
    });

    $("#searchByType").on("click", function ()
    {
        $.ajax({
            "url": "/api/MusicApi/SearchByType",
            "type": "GET",
            "contentType": 'application/json',
            "data": { "typeName": $("#typeName").val() },
            "dataType": "json",
            "success": function(data)
            {
                console.log(JSON.stringify(data));
                contenido1 = data;
                elements.prototype.tablatodo();
            }
        });
    });

    $("#score").on("click", function (event)
    {
        if ($(event.target).attr("type") == "button")
        {
            $.ajax({
                "url": "/api/MusicApi/UpdateScore",
                "type": "GET",
                "contentType": 'application/json',
                "data": { "score": $(event.target).val(), "id": 1 }, // He dejado el Id en 1 para hacer ejemplos con ese disco
                "dataType": "json",
                "success": function (json) {
                    console.log(JSON.stringify(json));
                }
            });
        }
    });

    var object = null;

    $.ajax({
        "url": "/api/MusicApi/GetAll",
        "type": "GET",
        "contentType": 'application/json',
        "data": object,
        "dataType": "json",
        "success": function (data)
        {
            contenido1 = data;
            elements.prototype.tablatodo();
        }
    });
});

elements = function () {
    var contenido1;
};

elements.prototype.tablatodo = function()
{
    document.getElementById("filas").innerHTML = "";
    for(contador = 0; contador < contenido1.length; contador++)
    {
        var fila = $('<tr><td>' + contenido1[contador].DiscName + '</td><td>' + contenido1[contador].Author + '</td><td>'+contenido1[contador].TypeSet+'</td><td>'+contenido1[contador].Score+'</td></tr>');
        $("#filas").append(fila);
    }
}