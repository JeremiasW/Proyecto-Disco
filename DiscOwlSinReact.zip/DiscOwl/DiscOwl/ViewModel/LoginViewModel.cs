﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DiscOwl.ViewModel
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Nombre de usuario requerido")]
        public String Username { get; set; }

        [Required(ErrorMessage = "Contraseña requerida")]
        public String Password { get; set; }
    }
}